const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import Image1 from "./components/Image1";
import IPhone1415Pro from "./screens/IPhone1415Pro";
import WelcomeToAppname from "./components/WelcomeToAppname";
import FeaturedExpertsText from "./components/FeaturedExpertsText";
import Frame from "./components/Frame";
import Component from "./components/Component";
import GroupComponentSet from "./components/GroupComponentSet";
import IPhone1415Pro1 from "./screens/IPhone1415Pro1";
import IPhone1415Pro2 from "./screens/IPhone1415Pro2";
import JacobJonesText from "./components/JacobJonesText";
import IPhone1415Pro3 from "./screens/IPhone1415Pro3";
import IPhone1415Pro4 from "./screens/IPhone1415Pro4";
import Text1 from "./components/Text1";
import Group from "./screens/Group";
import IPhone1415Pro5 from "./screens/IPhone1415Pro5";
import IPhone1415Pro6 from "./screens/IPhone1415Pro6";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  const [fontsLoaded, error] = useFonts({
    "NotoSans-Regular": require("./assets/fonts/NotoSans-Regular.ttf"),
    "NotoSans-Medium": require("./assets/fonts/NotoSans-Medium.ttf"),
    "NotoSans-SemiBold": require("./assets/fonts/NotoSans-SemiBold.ttf"),
    "NotoSans-Bold": require("./assets/fonts/NotoSans-Bold.ttf"),
    "NotoSans-ExtraBold": require("./assets/fonts/NotoSans-ExtraBold.ttf"),
  });

  if (!fontsLoaded && !error) {
    return null;
  }

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="IPhone1415Pro"
              component={IPhone1415Pro}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro1"
              component={IPhone1415Pro1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro2"
              component={IPhone1415Pro2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro3"
              component={IPhone1415Pro3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro4"
              component={IPhone1415Pro4}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Group"
              component={Group}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro5"
              component={IPhone1415Pro5}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro6"
              component={IPhone1415Pro6}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
