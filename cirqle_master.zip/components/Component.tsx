import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const Component = () => {
  return (
    <View style={styles.component1}>
      <View style={[styles.property1default, styles.property1defaultLayout]}>
        <Image
          style={styles.unionIcon}
          contentFit="cover"
          source={require("../assets/union.png")}
        />
        <Text style={[styles.signIn, styles.signTypo]}>SIGN IN</Text>
      </View>
      <View style={[styles.property1variant2, styles.property1defaultLayout]}>
        <Image
          style={styles.unionIcon}
          contentFit="cover"
          source={require("../assets/union1.png")}
        />
        <Text style={[styles.signIn1, styles.signTypo]}>SIGN IN</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1defaultLayout: {
    height: 51,
    left: 20,
    position: "absolute",
    width: 264,
  },
  signTypo: {
    textAlign: "left",
    fontFamily: FontFamily.nATS,
    fontSize: FontSize.size_5xl,
    left: "37.12%",
    top: "0%",
    position: "absolute",
  },
  unionIcon: {
    height: 48,
    width: 264,
  },
  signIn: {
    color: Color.colorWhite,
  },
  property1default: {
    top: 20,
  },
  signIn1: {
    color: Color.colorGray_200,
  },
  property1variant2: {
    top: 91,
  },
  component1: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 304,
    height: 162,
    overflow: "hidden",
  },
});

export default Component;
