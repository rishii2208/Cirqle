import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const Frame = () => {
  return (
    <View style={styles.groupParent}>
      <View style={styles.parentLayout}>
        <Image
          style={[styles.groupChild, styles.groupLayout2]}
          contentFit="cover"
          source={require("../assets/rectangle-21.png")}
        />
        <Image
          style={styles.intersectIcon}
          contentFit="cover"
          source={require("../assets/intersect.png")}
        />
        <Image
          style={[styles.groupItem, styles.groupLayout]}
          contentFit="cover"
          source={require("../assets/group-6.png")}
        />
        <Text style={[styles.janeCooper, styles.janeCooperTypo]}>
          Jane Cooper
        </Text>
        <Text
          style={[styles.softwareDeveloper, styles.dataAnalystTypo]}
        >{`Software
 Developer`}</Text>
      </View>
      <View style={styles.rectangleGroup}>
        <Image
          style={[styles.groupInner, styles.groupLayout2]}
          contentFit="cover"
          source={require("../assets/rectangle-22.png")}
        />
        <Image
          style={styles.intersectIcon}
          contentFit="cover"
          source={require("../assets/intersect1.png")}
        />
        <Image
          style={[styles.groupIcon, styles.groupLayout]}
          contentFit="cover"
          source={require("../assets/group-6.png")}
        />
        <Text style={[styles.estherHoward, styles.janeCooperTypo]}>
          Esther Howard
        </Text>
        <Text style={[styles.dataAnalyst, styles.dataAnalystTypo]}>
          Data Analyst
        </Text>
      </View>
      <View style={[styles.guyHawkinsParent, styles.parentLayout]}>
        <Text style={[styles.estherHoward, styles.janeCooperTypo]}>
          Guy Hawkins
        </Text>
        <Image
          style={[styles.groupChild, styles.groupLayout2]}
          contentFit="cover"
          source={require("../assets/rectangle-221.png")}
        />
        <Image
          style={styles.intersectIcon}
          contentFit="cover"
          source={require("../assets/intersect2.png")}
        />
        <Image
          style={[styles.groupChild1, styles.groupLayout]}
          contentFit="cover"
          source={require("../assets/group-7.png")}
        />
        <Text style={[styles.dataAnalyst, styles.dataAnalystTypo]}>{`Marketing 
head`}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  groupLayout2: {
    height: 137,
    borderRadius: Border.br_mid,
    top: 0,
    position: "absolute",
    width: 108,
  },
  groupLayout: {
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  janeCooperTypo: {
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.notoSansSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
    top: 143,
    position: "absolute",
  },
  dataAnalystTypo: {
    fontFamily: FontFamily.notoSansRegular,
    fontSize: FontSize.size_xs,
    top: 165,
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  parentLayout: {
    height: 197,
    width: 108,
  },
  groupChild: {
    left: 0,
  },
  intersectIcon: {
    height: 27,
    width: 108,
  },
  groupItem: {
    width: "54.63%",
    top: "58.38%",
    right: "23.15%",
    bottom: "33.45%",
    left: "22.22%",
    height: "8.17%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
  },
  janeCooper: {
    left: 5,
  },
  softwareDeveloper: {
    left: 5,
  },
  groupInner: {
    left: 5,
  },
  groupIcon: {
    height: "8.9%",
    width: "50.86%",
    top: "62.98%",
    right: "24.14%",
    bottom: "28.12%",
    left: "25%",
  },
  estherHoward: {
    left: 0,
  },
  dataAnalyst: {
    left: 0,
  },
  rectangleGroup: {
    width: 116,
    height: 181,
    marginLeft: 13,
  },
  groupChild1: {
    width: "74.07%",
    top: "57.87%",
    right: "14.81%",
    bottom: "33.96%",
    left: "11.11%",
    height: "8.17%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
  },
  guyHawkinsParent: {
    marginLeft: 13,
  },
  groupParent: {
    width: 375,
    flexDirection: "row",
  },
});

export default Frame;
