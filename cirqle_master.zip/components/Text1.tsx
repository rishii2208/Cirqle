import * as React from "react";
import { Text, StyleSheet } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const Text1 = () => {
  return <Text style={styles.text}>{` `}</Text>;
};

const styles = StyleSheet.create({
  text: {
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.notoSansRegular,
    color: Color.colorWhite,
    textAlign: "left",
  },
});

export default Text1;
