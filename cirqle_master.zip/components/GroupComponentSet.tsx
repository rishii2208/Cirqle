import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const GroupComponentSet = () => {
  return (
    <View style={styles.property1defaultParent}>
      <View style={[styles.property1default, styles.property1defaultLayout]}>
        <Image
          style={styles.unionIcon}
          contentFit="cover"
          source={require("../assets/union2.png")}
        />
        <Text style={[styles.signUp, styles.signTypo]}>SIGN UP</Text>
      </View>
      <View style={[styles.property1variant2, styles.property1defaultLayout]}>
        <Image
          style={styles.unionIcon}
          contentFit="cover"
          source={require("../assets/union1.png")}
        />
        <Text style={[styles.signUp1, styles.signTypo]}>SIGN UP</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1defaultLayout: {
    height: 51,
    left: 20,
    position: "absolute",
    width: 264,
  },
  signTypo: {
    textAlign: "left",
    fontFamily: FontFamily.nATS,
    fontSize: FontSize.size_5xl,
    left: "36.74%",
    top: "0%",
    position: "absolute",
  },
  unionIcon: {
    height: 48,
    width: 264,
  },
  signUp: {
    color: Color.colorWhite,
  },
  property1default: {
    top: 20,
  },
  signUp1: {
    color: Color.colorGray_200,
  },
  property1variant2: {
    top: 91,
  },
  property1defaultParent: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: Color.colorBlueviolet,
    borderWidth: 1,
    width: 304,
    height: 162,
    overflow: "hidden",
  },
});

export default GroupComponentSet;
