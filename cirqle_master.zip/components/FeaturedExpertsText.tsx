import * as React from "react";
import { Text, StyleSheet } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const FeaturedExpertsText = () => {
  return <Text style={styles.featuredExperts}>Featured Experts</Text>;
};

const styles = StyleSheet.create({
  featuredExperts: {
    fontSize: FontSize.size_3xl,
    fontWeight: "600",
    fontFamily: FontFamily.notoSansSemiBold,
    color: Color.colorWhite,
    textAlign: "left",
  },
});

export default FeaturedExpertsText;
