import * as React from "react";
import { Text, StyleSheet } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const WelcomeToAppname = () => {
  return (
    <Text style={styles.welcomeToAppname}>“Welcome to [appname], Jacob”</Text>
  );
};

const styles = StyleSheet.create({
  welcomeToAppname: {
    fontSize: FontSize.size_11xl,
    fontWeight: "600",
    fontFamily: FontFamily.notoSansSemiBold,
    color: Color.colorWhite,
    textAlign: "left",
    width: 375,
  },
});

export default WelcomeToAppname;
