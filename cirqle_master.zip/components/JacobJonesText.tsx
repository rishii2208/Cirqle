import * as React from "react";
import { Text, StyleSheet } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const JacobJonesText = () => {
  return <Text style={styles.jacobJones}>Jacob Jones</Text>;
};

const styles = StyleSheet.create({
  jacobJones: {
    fontSize: FontSize.size_lg,
    fontWeight: "700",
    fontFamily: FontFamily.notoSansBold,
    color: Color.colorGray_200,
    textAlign: "left",
    width: 121,
    height: 28,
  },
});

export default JacobJonesText;
